Thanks Spiderdave for this converter...

To convert levels, drag a modified SMB1 rom into the bat file.
After this, build your rom with build.bat